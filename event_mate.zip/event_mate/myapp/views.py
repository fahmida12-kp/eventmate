from django.shortcuts import render

# Create your views here.

def login_get(request):
    return render(request,'login.html')
def admin_index(request):
    return render(request,'admin/admin_index.html')

def add_course(request):
    return render(request,'admin/Add_course.html')

def add_dept(request):
    return render(request,'admin/Add_dep.html')

def manage_course(request):
    return render(request,'admin/Manage_course.html')

def manage_dep(request):
    return  render (request,'admin/manage_dep.html')
def verify_event_course(request):
    return render (request,'admin/Verify_event_course.html')
def view_more_event(request):
    return render (request,'admin/View_more_event.html')
def design (request):
    return render (request,'admin/Design.html')
def view_feedback(request):
    return render (request,'admin/View_feedback.html')
def view_complaint (request):
    return render (request,'admin/View_complaint.html')
def send_reply(request):
    return render (request,'admin/Send_reply.html')
def event_analytics_and_participation(request):
    return render(request,'admin/Event_ analytics_ and _participantion.html')
def attendence(request):
    return render (request,'admin/Attendece.html')


# =================== staff=====================




def add_event (request):
    return render(request,'staff/Add_event.html')
def add_judge (request):
    return render(request,'staff/Add_judge.html')
def assign_cordination (request):
    return render(request,'staff/Assign_cordination.html')
def assign_judge (request):
    return render(request,'staff/Assign_judge.html')
def event_updates (request):
    return render(request,'staff/Event_updates.html')
def  View_assigned_judge(request):
    return render(request,'staff/View_assigned_judge.html')
def view_event(request):
    return render(request,'staff/View_event.html')
def view_event_update(request):
    return render(request,'staff/View_event_updates.html')
def view_expense(request):
    return render(request,'staff/View_expense.html')
def view_judge(request):
    return render(request,'staff/View_judge.html')
def view_student(request):
    return render(request,'staff/View_studentd.html')
def add_attendence(request):
    return render(request,'staff/Add_attendence.html')
def staff_index(request):
    return render(request,'staff/Staff_index.html')



from django.contrib import admin
from django.urls import path

from myapp import views

urlpatterns = [
    path('login_get/', views.login_get),
    path('add_course/', views.add_course),
    path('add_dept/', views.add_dept),
    path('manage_course/',views.manage_course),
    path('manage_dep/',views.manage_dep),
    path('verify_event_course/', views. verify_event_course),
    path('view_more_event/',views.view_more_event),
    path('design/',views.design ),
    path('view_feedback/',views.view_feedback),
    path('view_complaint/',views.view_complaint),
    path('send_reply/',views.send_reply),
    path('event_analytics_and_participation/',views.event_analytics_and_participation),
    path('attendence/',views.attendence),
    path('admin_/',views.admin_index),


    # ============= staff==========


    path('add_event/', views.add_event),
    path('add_judge/', views.add_judge),
    path('assign_cordination/', views.assign_cordination),
    path('assign_judge/', views.assign_judge),
    path('event_updates/', views.event_updates),
    path('View_assigned_judge/',views.View_assigned_judge),
    path('view_event/', views.view_event),
    path('view_event_update/',views.view_event_update),
    path('view_expense/', views.view_expense),
    path('view_judge/', views.view_judge),
    path('view_student/', views.view_student),
    path('add_attendence/', views.add_attendence),
    path('staff_index/', views.staff_index),
]




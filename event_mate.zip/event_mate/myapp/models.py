from django.db import models

# Create your models here.

class department_table(models.Model):
    name=models.CharField(max_length=100)
    details=models.CharField(max_length=500)

class course_table(models.Model):
    course= models.CharField(max_length=100)
    department_id=models.ForeignKey(department_table,on_delete=models.CASCADE)
    details=models.CharField(max_length=500)

class event_table(models.Model):
    course=models.CharField(max_length=100)
    event=models.CharField(max_length=500)
    type=models.CharField(max_length=100)
    amount=models.IntegerField(max_length=10000)
    status=models.CharField(max_length=100)
    details=models.CharField(max_length=100)


class feedback_table(models.Model):
    feedback=models.CharField(max_length=100)
    date=models.DateField()
    rating=models.FloatField()

class coordinator_table(models.Model):
    name=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    phone=models.IntegerField()
    place=models.CharField(max_length=100)
    district=models.CharField(max_length=100)
    login=models.ForeignKey(user,on_delete=models.CASCADE)
    designation=models.CharField(max_length=100)

class judge_table(models.Model):
    name=models.CharField(max_length=100)
    email=models.CharField(max_length=100)
    phone=models.IntegerField()
    photo=models.FileField()
    gender=models.CharField(max_length=100)
    qualification=models.CharField(max_length=100)
    type=models.CharField(max_length=100)
    login=models.ForeignKey(user,on_delete=models.CASCADE)

class event_update_table(models.Model):
    event=models.ForeignKey(event_table,on_delete=models.CASCADE)
    date=models.DateField()
    new_update=models.CharField(max_length=500)


class attendace_table(models.Model):
    event=models.ForeignKey(event_table,on_delete=models.CASCADE)
    student=models.ForeignKey(department_table,on_delete=models.CASCADE)
    date=models.DateField()
    attendace=models.CharField()

class assign_judge(models.Model):
    event_